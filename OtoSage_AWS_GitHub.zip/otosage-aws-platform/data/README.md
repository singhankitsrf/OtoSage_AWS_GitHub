# Data
Only non-image inventory metadata is committed. The AWS workflow expects the
actual dataset in a private S3 prefix such as `s3://.../raw/`.
