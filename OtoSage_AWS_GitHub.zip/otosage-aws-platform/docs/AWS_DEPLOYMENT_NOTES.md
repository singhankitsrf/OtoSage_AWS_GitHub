# AWS Deployment Notes

The architecture follows current AWS service capabilities:

- SageMaker Asynchronous Inference accepts queued inference requests and writes
  outputs to S3.
- Asynchronous endpoints can be configured for autoscaling down to zero.
- SageMaker Pipelines supports processing, training, evaluation, conditional
  logic and model-registration workflows.
- SageMaker Model Registry provides versioning and approval state.
- The default project container family is parameterized through environment
  variables so a supported PyTorch DLC version can be changed without rewriting
  the pipeline.

Environment overrides:

```bash
export SAGEMAKER_PYTORCH_VERSION=2.5.1
export SAGEMAKER_PYTHON_VERSION=py311
```

Always verify service availability and pricing in the selected AWS Region before
a real deployment.
