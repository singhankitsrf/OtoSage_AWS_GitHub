# Cost Controls

- SageMaker Asynchronous Inference is designed here for scale-to-zero in
  development or low-traffic periods.
- Inference S3 objects expire after 30 days by default.
- DynamoDB uses PAY_PER_REQUEST.
- CloudWatch log retention is bounded.
- Training/processing instance types are pipeline parameters.
- Terraform makes teardown explicit.

Before running GPU training or endpoint tests, check current AWS pricing in the
chosen region. A strong GitHub portfolio does not require leaving paid endpoints
running continuously.
