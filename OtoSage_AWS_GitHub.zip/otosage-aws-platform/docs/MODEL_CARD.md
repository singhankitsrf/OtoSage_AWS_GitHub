# Model Card — OtoSage-AWS

**Task:** five-class otoscopic image classification  
**Architecture:** EfficientNetV2-S transfer learning  
**Training:** Amazon SageMaker Training  
**Governance:** SageMaker Model Registry  
**Serving:** SageMaker Asynchronous Inference

The default quality-gate values (`macro F1 >= 0.80`, `ECE <= 0.15`) are example
engineering thresholds, **not claimed model performance**.

This repository is for research/engineering demonstration and is not intended
for autonomous diagnosis, treatment recommendation, emergency decision making,
or clinical use without appropriate validation and approval.
