# Security Design

Included:
- private S3 buckets
- S3 public-access blocks
- server-side encryption
- DynamoDB point-in-time recovery
- expiring pre-signed upload/result URLs
- IAM roles for Lambda and SageMaker
- GitHub Actions OIDC pattern
- no credentials, raw images, model weights or Terraform state in Git

Production hardening should add authenticated API clients, WAF/throttling,
customer-managed KMS keys, private networking/VPC endpoints where appropriate,
CloudTrail/audit aggregation, GuardDuty/Security Hub, secret management, formal
data-retention controls and organization-specific clinical governance.
