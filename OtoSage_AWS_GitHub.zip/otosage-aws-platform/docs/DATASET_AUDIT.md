# Dataset Audit

The supplied source archive was inspected before this AWS project was generated.

- Total image entries: **3000**
- Classes: **5**
- Archive-level repeated-content groups: **78**
- Duplicate surplus flagged at archive level: **78**
- Estimated canonical files after this warning screen: **2922**

| Class | Archive files | Duplicate surplus warning | Canonical estimate |
|---|---:|---:|---:|
| Acute Otitis Media | 600 | 78 | 522 |
| Cerumen Impaction | 600 | 0 | 600 |
| Chronic Otitis Media | 600 | 0 | 600 |
| Myringosclerosis | 600 | 0 | 600 |
| Normal | 600 | 0 | 600 |

## Training-time rule

Archive CRC is only an early warning. The SageMaker preprocessing step recomputes
**SHA-256** over extracted image files. It also fails the pipeline if identical
file bytes appear under different labels.

Exact-duplicate surplus images are excluded before deterministic stratified
train/validation/test splitting.

## Before any clinical claim

Add patient/exam-level grouped validation when identifiers exist, near-duplicate
analysis, device/site stratification, label adjudication, external validation,
and clinically appropriate subgroup analysis.
