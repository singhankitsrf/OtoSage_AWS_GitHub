# GitHub Upload Guide

## Create the repository

Create a **public** GitHub repository named:

`otosage-aws-platform`

Suggested description:

`AWS-native Healthcare AI: SageMaker Pipelines/Model Registry, event-driven async inference, API Gateway, Lambda, S3, DynamoDB, SNS, Terraform and GitHub Actions OIDC.`

Do not initialize it with another README, license or `.gitignore`.

## Upload from your computer

Open PowerShell/Terminal inside the extracted project directory:

```bash
git init
git branch -M main
git add .
git status
git commit -m "feat: launch AWS-native OtoSage healthcare AI platform"
git remote add origin https://github.com/YOUR_USERNAME/otosage-aws-platform.git
git push -u origin main
```

Before the commit, verify that no `.rar`, medical image, model weight, `.env`,
AWS credential or Terraform state file is staged.

## Repository topics

Add:

`aws`, `sagemaker`, `healthcare-ai`, `medical-imaging`, `mlops`, `pytorch`,
`serverless`, `lambda`, `api-gateway`, `dynamodb`, `terraform`,
`github-actions`, `model-registry`, `asynchronous-inference`

## Pin the repository

GitHub profile -> **Customize your pins** -> pin `otosage-aws-platform`.

## GitHub Actions OIDC

After you have created the optional OIDC role, add:

- repository secret: `AWS_GITHUB_ROLE_ARN`
- repository variable: `AWS_REGION`

This project deliberately avoids storing a permanent AWS access key in GitHub.

## After the first real AWS run

Add genuine evidence only:

- SageMaker Pipeline DAG screenshot
- Model Registry screenshot
- actual evaluation metrics
- CloudWatch dashboard screenshot
- actual API response example
- measured inference latency
- a small documented AWS demo cost

Do not invent accuracy, latency or cost numbers.
