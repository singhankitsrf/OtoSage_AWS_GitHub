# Recruiter / Interview Story

## 30-second pitch

“I built an AWS-native Healthcare AI platform for otoscopic image analysis.
I used SageMaker Processing for data validation and duplicate leakage control,
SageMaker Training/Pipelines for managed model development, Model Registry for
governance, and an event-driven inference architecture using API Gateway,
Lambda, S3, DynamoDB, SNS and SageMaker Asynchronous Inference. I provisioned
the platform with Terraform and designed CI/CD around GitHub OIDC instead of
long-lived AWS keys.”

## Strong resume bullets

- Architected an AWS-native Healthcare AI platform spanning secure S3 ingestion,
  SageMaker Pipelines, Model Registry, asynchronous inference, serverless APIs,
  observability and Terraform-based infrastructure-as-code.

- Implemented leakage-aware medical-image processing with SHA-256 exact
  duplicate detection, cross-label conflict validation, deterministic splitting
  and governed model quality gates.

- Designed event-driven inference with API Gateway, Lambda, S3, DynamoDB, SNS
  and SageMaker Asynchronous Inference, including cost-aware autoscaling and
  GitHub Actions OIDC deployment.

## Interview topics supported by this repository

- medical-image data leakage
- managed MLOps vs self-managed ML platforms
- async/event-driven architecture
- model governance and manual approval
- IAM and federated CI/CD
- calibration and selective review
- cloud cost control
- Terraform lifecycle boundaries
